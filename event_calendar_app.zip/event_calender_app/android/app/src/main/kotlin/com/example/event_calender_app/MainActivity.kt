package com.example.event_calender_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
