import 'package:event_calender_app/presentation/event_calendar_app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const EventCalendarApp());
}
